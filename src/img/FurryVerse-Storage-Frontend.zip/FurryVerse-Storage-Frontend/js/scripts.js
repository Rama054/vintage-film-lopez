var options = {
    series: [
    {
      name: 'Visitas',
      data: [1,2,3,4,5,64,7,8,9,10]
    },
    {
      name: 'Ingresos',
      data: [1,2,3,45,5,6,7,8,9,10]
    },
    {
      name: 'Peticiones',
      data: [1,20,3,4,5,6,7,8,9,10]
    }
  ],
    chart: {
    type: 'area',
    height: '100%',
    width: '100%',
    foreColor: '#ffffff',
    stacked: true,
    events: {
      selection: function (chart, e) {
        console.log(new Date(e.xaxis.min))
      }
    },
  },
  colors: ['#008FFB', '#00E396', '#CED4DC'],
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'smooth'
  },
  fill: {
    type: 'gradient',
    gradient: {
      opacityFrom: 0.6,
      opacityTo: 0.8,
    }
  },
  legend: {
    position: 'top',
    horizontalAlign: 'left'
  },
  xaxis: {
    categories: ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"]
  },
  };

  var chart = new ApexCharts(document.querySelector("#chart"), options);
  chart.render();
